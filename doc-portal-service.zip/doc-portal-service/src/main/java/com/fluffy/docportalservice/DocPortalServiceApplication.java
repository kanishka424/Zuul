package com.fluffy.docportalservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DocPortalServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DocPortalServiceApplication.class, args);
	}

}
